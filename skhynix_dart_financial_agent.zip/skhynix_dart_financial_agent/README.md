[![🔗 대시보드 바로가기](https://img.shields.io/badge/%F0%9F%94%97%20%EB%8C%80%EC%8B%9C%EB%B3%B4%EB%93%9C-%EB%B0%94%EB%A1%9C%EA%B0%80%EA%B8%B0-3267d6?style=for-the-badge)](https://hsc-class02.github.io/jh_skhynix/)

# SK hynix OpenDART Financial Agent

2010년 이후 SK하이닉스 사업·반기·분기보고서의 공시 메타데이터와 재무제표 데이터를 OpenDART API로 수집하고, 주요 재무수치 및 비율을 계산해 GitHub Pages 대시보드에 표시합니다.

## 기능
- DART 공시 목록 및 원문 ZIP 다운로드(`data/raw/reports/`)
- 재무제표 API 데이터 캐시와 정규화 데이터(`data/processed/`)
- Annual / Half-year / Quarterly 데이터 표와 상단 그래프
- 매출 성장률, 매출총이익률, 영업이익률, 순이익률, 유동비율, 부채비율, 자기자본비율, CFO/순이익, 이자보상배율, 순차입금, FCF 등
- 매월 1일 GitHub Actions 자동 수집·커밋·GitHub Pages 배포
- Actions 탭에서 수동 실행 가능

## 1. OpenDART API 키 설정
1. [OpenDART](https://opendart.fss.or.kr/)에 가입하고 인증키를 발급받습니다.
2. GitHub 저장소 `Settings → Secrets and variables → Actions → New repository secret`으로 이동합니다.
3. 이름을 `DART_API_KEY`, 값은 발급받은 인증키로 저장합니다.
4. `Actions` 탭에서 `Update DART data and deploy dashboard`를 선택한 후 `Run workflow`를 실행합니다.

API 키는 코드, README, 브라우저 대시보드에 입력하지 않습니다. GitHub Actions secret으로만 전달됩니다.

## 2. GitHub Pages 활성화
1. 저장소 `Settings → Pages`로 이동합니다.
2. Build and deployment의 Source를 **GitHub Actions**로 설정합니다.
3. `Settings → Actions → General`에서 Actions가 허용되어 있는지 확인합니다.
4. 위 수동 워크플로우를 실행하고 성공한 뒤 `https://hsc-class02.github.io/jh_skhynix/`를 확인합니다.

> ZIP에는 `.github/workflows/update-and-deploy.yml`이 포함되어 있습니다. GitHub Actions 자동화에 필요한 디렉터리이므로 삭제하지 마세요. `.DS_Store`, `__pycache__`, `.env` 같은 불필요한 숨김/임시 파일은 ZIP에 넣지 않았습니다.

## 3. GitHub 저장소에 업로드
ZIP을 압축 해제한 뒤 파일과 폴더를 저장소 루트에 업로드합니다. `.github` 폴더도 함께 업로드해야 자동 업데이트가 작동합니다. 기존 파일과 충돌할 수 있으므로 기존 저장소에 업로드하기 전에 변경사항을 검토하세요.

## 4. GitHub About 링크
저장소 첫 화면 오른쪽 `About`의 편집 아이콘을 눌러 Website에 `https://hsc-class02.github.io/jh_skhynix/`를 입력합니다. 저장소 설명에도 대시보드 주소를 추가할 수 있습니다.

## 5. 분석 정의 및 한계
- 연결재무제표(CFS)를 우선하며, 연결 자료가 없는 경우 별도재무제표(OFS)를 대체 조회합니다. 대시보드에서 기간·연결/별도 기준을 혼합해 비교하지 않도록 원본 계정 구분을 확인하세요.
- DART 계정명은 연도·보고서에 따라 달라질 수 있어 별칭 기반으로 추출합니다. 누락된 값은 0으로 대체하지 않고 공란으로 둡니다.
- CFO, CAPEX, FCF의 정의는 첨부 실무 가이드에 따라 확인합니다. 현재 FCF는 CFO에서 유형·무형자산 취득액의 절댓값을 차감하는 단순 정의입니다.
- ROA/ROE/ROIC, DSO/DIO/DPO/CCC, PER/PBR/EV/EBITDA는 평균 잔액·주가·시가총액·이자·세부 주석 데이터 등 추가 정합화가 필요해 자동 계산 범위에서 일부 제외되어 있습니다.
- 분기·반기 손익 및 현금흐름은 누적 값으로 보고되는 경우가 있습니다. 단독 분기 값으로 해석하기 전 원문 공시를 확인하세요.
- 국내 peer firms는 삼성전자(직접 비교군), DB하이텍·한미반도체·주성엔지니어링·원익IPS·PSK·ISC(반도체 생태계 비교군)로 나눠 표시합니다. 모든 기업이 SK하이닉스와 동일 사업을 하는 것은 아닙니다.

## Peer Firms
| 기업 | 종목코드 | 비교 관계 |
|---|---:|---|
| 삼성전자 | 005930 | 메모리 반도체 직접 비교 대상 |
| DB하이텍 | 000990 | 국내 반도체 제조·파운드리 비교군 |
| 한미반도체 | 042700 | 반도체 후공정 장비 생태계 |
| 주성엔지니어링 | 036930 | 반도체 공정 장비 생태계 |
| 원익IPS | 240810 | 반도체 공정 장비 생태계 |
| PSK | 319660 | 반도체 공정 장비 생태계 |
| ISC | 095340 | 반도체 테스트 소켓 생태계 |

## 로컬 실행
```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
# macOS/Linux: export DART_API_KEY='발급받은키'
# PowerShell: $env:DART_API_KEY='발급받은키'
python scripts/update_data.py
```

## Workflow schedule
`.github/workflows/update-and-deploy.yml`은 매월 1일 00:20 UTC(한국시간 09:20)에 실행됩니다. GitHub Actions의 예약 실행은 GitHub 측 부하에 따라 지연될 수 있습니다.
