from __future__ import annotations
import os, sys, json, time, zipfile, io
from pathlib import Path
from datetime import datetime
import requests
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from src.analysis import normalize_statement, add_ratios
API = "https://opendart.fss.or.kr/api"
KEY = os.getenv("DART_API_KEY", "").strip()
CONFIG = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
RAW = ROOT / "data/raw/reports"; RAW.mkdir(parents=True, exist_ok=True)
PROC = ROOT / "data/processed"; PROC.mkdir(parents=True, exist_ok=True)
DOCS = ROOT / "docs"; DOCS.mkdir(parents=True, exist_ok=True)
if not KEY:
    raise SystemExit("DART_API_KEY is missing. Add it in GitHub Settings > Secrets and variables > Actions.")
S = requests.Session()

def get_json(endpoint, params):
    p = dict(params); p["crtfc_key"] = KEY
    for attempt in range(5):
        try:
            resp = S.get(f"{API}/{endpoint}", params=p, timeout=45); resp.raise_for_status()
            data = resp.json()
            if data.get("status") in ("000", "013"): return data
            if data.get("status") == "020": raise RuntimeError("DART API request limit exceeded")
            return data
        except (requests.RequestException, ValueError) as e:
            if attempt == 4: raise
            time.sleep(2 ** attempt)

def company_code():
    p = {"crtfc_key": KEY}
    resp = S.get(f"{API}/corpCode.xml", params=p, timeout=90); resp.raise_for_status()
    z = zipfile.ZipFile(io.BytesIO(resp.content))
    xml = z.read("CORPCODE.xml")
    import xml.etree.ElementTree as ET
    root = ET.fromstring(xml)
    for c in root.findall("list"):
        if (c.findtext("stock_code") or "").strip() == CONFIG["stock_code"]:
            return c.findtext("corp_code")
    raise RuntimeError("SK hynix stock code not found in DART corpCode.xml")

def save_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

def main():
    corp = company_code()
    now_year = datetime.now().year
    filings = []
    for year in range(CONFIG["start_year"], now_year + 1):
        result = get_json("list.json", {"corp_code": corp, "bgn_de": f"{year}0101", "end_de": f"{year}1231", "page_count": 100})
        if result.get("status") == "013": continue
        if result.get("status") != "000":
            print(f"filing list warning {year}: {result.get('status')} {result.get('message')}"); continue
        for f in result.get("list", []):
            name = f.get("report_nm", "")
            if any(x in name for x in ("사업보고서", "반기보고서", "분기보고서")):
                filings.append(f)
        time.sleep(.15)
    # Keep report metadata and raw filing source; deduplicate by receipt number.
    unique = {f.get("rcept_no"): f for f in filings if f.get("rcept_no")}
    filings = sorted(unique.values(), key=lambda f: (f.get("rcept_dt", ""), f.get("rcept_no", "")))
    save_json(RAW / "filings.json", {"corp_code": corp, "stock_code": CONFIG["stock_code"], "filings": filings})
    # Download official filing documents as the ZIP returned by document.xml.
    # Existing files are retained to avoid repeat API calls and repository churn.
    source_dir = RAW / "source_reports"; source_dir.mkdir(parents=True, exist_ok=True)
    for f in filings:
        receipt = f.get("rcept_no")
        if not receipt: continue
        dest = source_dir / f"{receipt}.zip"
        if dest.exists(): continue
        try:
            response = S.get(f"{API}/document.xml", params={"crtfc_key": KEY, "rcept_no": receipt}, timeout=90)
            response.raise_for_status()
            if response.content[:2] == b"PK":
                dest.write_bytes(response.content)
            else:
                print(f"Source report unavailable for {receipt}; keeping filing metadata only")
        except requests.RequestException as exc:
            print(f"Source report download warning {receipt}: {exc}")
        time.sleep(.15)
    annual, half, quarterly = [], [], []
    for f in filings:
        name, year = f.get("report_nm", ""), int(f.get("bsns_year", "0") or 0)
        if year < CONFIG["start_year"]: continue
        # Report code inferred from report title; financial statement endpoint needs year/report code.
        if "사업보고서" in name: code, category = "11011", "annual"
        elif "반기보고서" in name: code, category = "11012", "half_year"
        elif "분기보고서" in name and "3분기" in name: code, category = "11014", "quarterly"
        elif "분기보고서" in name: code, category = "11013", "quarterly"
        else: continue
        key = f"{year}_{code}"
        cached = RAW / f"{key}.json"
        if cached.exists():
            data = json.loads(cached.read_text(encoding="utf-8"))
        else:
            data = get_json("fnlttSinglAcntAll.json", {"corp_code": corp, "bsns_year": str(year), "reprt_code": code, "fs_div": "CFS"})
            if data.get("status") == "013" or data.get("status") != "000":
                # Retry with separate statements only if consolidated data is unavailable.
                data = get_json("fnlttSinglAcntAll.json", {"corp_code": corp, "bsns_year": str(year), "reprt_code": code, "fs_div": "OFS"})
            save_json(cached, data); time.sleep(.2)
        rows = data.get("list", [])
        values = normalize_statement(rows)
        if not values: continue
        item = {"year": year, "category": category, "report_name": name, "receipt_no": f.get("rcept_no"), "receipt_date": f.get("rcept_dt"), "report_code": code, **values}
        (annual if category == "annual" else half if category == "half_year" else quarterly).append(item)
    # Ratios use prior available report within the same category; ROA/ROE are omitted unless average balances can be paired safely.
    for group in (annual, half, quarterly):
        group.sort(key=lambda x: (x["year"], x["report_code"]))
        prev = None
        for item in group:
            item.update(add_ratios(item, prev)); prev = item
    save_json(PROC / "annual.json", annual); save_json(PROC / "half_year.json", half); save_json(PROC / "quarterly.json", quarterly)
    # Static dashboard consumes only this generated file; no API key reaches the browser.
    dashboard = {"company": CONFIG["company_name"], "stock_code": CONFIG["stock_code"], "updated_at": datetime.now().astimezone().isoformat(timespec="minutes"), "annual": annual, "half_year": half, "quarterly": quarterly, "peers": CONFIG["peer_firms"], "notes": ["금액 단위는 DART 원본 금액 기준입니다.", "공시 원본의 계정명 차이로 일부 항목은 공란일 수 있습니다.", "분기보고서 손익·현금흐름은 누적 공시 기준일 수 있으므로 분기 단독 수치로 해석하기 전에 원문을 확인하세요.", "주가 기반 PER·PBR·EV/EBITDA는 시장가격·주식수 데이터가 필요해 기본 수집 범위에서 제외했습니다."]}
    save_json(DOCS / "data.json", dashboard)
    print(f"Updated filings={len(filings)} annual={len(annual)} half={len(half)} quarterly={len(quarterly)}")

if __name__ == "__main__": main()
