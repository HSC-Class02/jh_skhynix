"""Financial statement normalization and ratio calculations."""
from __future__ import annotations
import pandas as pd

ALIASES = {
    "revenue": ["매출액", "수익(매출액)", "영업수익"],
    "gross_profit": ["매출총이익", "매출총손익"],
    "operating_income": ["영업이익", "영업이익(손실)", "영업손익"],
    "pretax_income": ["법인세비용차감전순이익", "법인세비용차감전순이익(손실)"],
    "net_income": ["당기순이익", "당기순이익(손실)"],
    "controlling_net_income": ["지배기업의 소유주에게 귀속되는 당기순이익", "지배기업 소유주지분 순이익"],
    "assets": ["자산총계"], "current_assets": ["유동자산"],
    "cash": ["현금및현금성자산", "현금 및 현금성자산"],
    "receivables": ["매출채권", "매출채권및기타채권"], "inventory": ["재고자산"],
    "liabilities": ["부채총계"], "current_liabilities": ["유동부채"],
    "equity": ["자본총계"], "short_borrowings": ["단기차입금"],
    "long_borrowings": ["장기차입금"], "interest_expense": ["이자비용"],
    "cfo": ["영업활동현금흐름", "영업활동으로 인한 현금흐름"],
    "cfi": ["투자활동현금흐름", "투자활동으로 인한 현금흐름"],
    "cff": ["재무활동현금흐름", "재무활동으로 인한 현금흐름"],
    "capex_ppe": ["유형자산의 취득"], "capex_intangible": ["무형자산의 취득"]
}

def normalize_statement(rows: list[dict]) -> dict:
    """Map DART account names to canonical values, preferring consolidated statements."""
    out = {}
    if not rows:
        return out
    # Prefer CFS (consolidated) over OFS (separate); API ordering can vary.
    rows = sorted(rows, key=lambda r: 0 if r.get("fs_div") == "CFS" else 1)
    for key, aliases in ALIASES.items():
        for alias in aliases:
            matches = [r for r in rows if r.get("account_nm", "").strip() == alias]
            if matches:
                row = matches[0]
                raw = row.get("thstrm_amount")
                try: out[key] = float(str(raw).replace(",", "")) if raw not in (None, "", "-") else None
                except ValueError: out[key] = None
                out[key + "_account"] = alias
                out[key + "_fs_div"] = row.get("fs_div")
                break
    return out

def add_ratios(row: dict, previous: dict | None = None) -> dict:
    r = dict(row)
    def div(a, b): return a / b if a is not None and b not in (None, 0) else None
    r["gross_margin"] = div(r.get("gross_profit"), r.get("revenue"))
    r["operating_margin"] = div(r.get("operating_income"), r.get("revenue"))
    r["net_margin"] = div(r.get("net_income"), r.get("revenue"))
    r["current_ratio"] = div(r.get("current_assets"), r.get("current_liabilities"))
    r["debt_to_equity"] = div(r.get("liabilities"), r.get("equity"))
    r["equity_ratio"] = div(r.get("equity"), r.get("assets"))
    debt = (r.get("short_borrowings") or 0) + (r.get("long_borrowings") or 0)
    r["interest_bearing_debt"] = debt
    r["net_debt"] = debt - (r.get("cash") or 0)
    r["fcf"] = (r.get("cfo") or 0) - (abs(r.get("capex_ppe") or 0) + abs(r.get("capex_intangible") or 0))
    r["cfo_to_net_income"] = div(r.get("cfo"), r.get("net_income"))
    r["interest_coverage"] = div(r.get("operating_income"), r.get("interest_expense"))
    if previous:
        r["revenue_growth"] = div(r.get("revenue") - previous.get("revenue"), previous.get("revenue")) if r.get("revenue") is not None and previous.get("revenue") not in (None, 0) else None
    else: r["revenue_growth"] = None
    return r
